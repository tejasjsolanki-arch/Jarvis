# JARVIS V2

JARVIS V2 adds a real AI backend and iPhone Shortcut execution.

Architecture:

iPhone Safari/PWA
       |
       | HTTPS POST /jarvis
       v
Node/Express backend
       |
       | OpenAI Responses API
       v
AI returns:
reply + action + input
       |
       v
iPhone opens:
shortcuts://run-shortcut?name=...&input=...

The AI key stays on the server.

## Backend

1. Install Node.js on a computer/server.
2. cd server
3. npm install
4. Copy .env.example to .env
5. Put your API key in OPENAI_API_KEY.
6. npm start
7. Deploy the backend to an HTTPS host.
8. Put that HTTPS backend URL into web/app.js as API_BASE.

Do NOT put your OpenAI API key in web/app.js.

## Web app

Host the `web` folder over HTTPS. Open the site in Safari and use Add to Home Screen.

## iPhone Shortcuts

Follow SHORTCUTS_SETUP.md and create the six shortcuts with the exact names.

## Important iOS behavior

The browser can request the iOS Shortcuts URL scheme, but iOS may show a confirmation or leave Safari when launching a shortcut. The shortcut itself controls what the iPhone does.

## AI model

The server is configured for `gpt-5.6-luna`. If your API account exposes a different/current model ID, change the `model` field in server/server.js.
