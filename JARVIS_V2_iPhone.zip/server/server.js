import "dotenv/config";
import express from "express";
import cors from "cors";
import OpenAI from "openai";

const app = express();
const port = process.env.PORT || 3000;
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.use(cors({ origin: process.env.ALLOWED_ORIGIN || "*" }));
app.use(express.json({ limit: "64kb" }));

const shortcutNames = {
  openApp: "JARVIS Open App",
  reminder: "JARVIS Reminder",
  timer: "JARVIS Timer",
  note: "JARVIS Note",
  webSearch: "JARVIS Web Search",
  music: "JARVIS Music"
};

app.get("/health", (_, res) => res.json({ ok: true, assistant: "JARVIS V2" }));

app.post("/jarvis", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();
    if (!message) return res.status(400).json({ error: "message is required" });

    const response = await client.responses.create({
      model: "gpt-5.6-luna",
      input: [
        {
          role: "system",
          content: `You are JARVIS, a concise personal iPhone assistant.
Return ONLY valid JSON with this shape:
{
  "reply": "short natural response",
  "action": "none|openApp|reminder|timer|note|webSearch|music",
  "input": "text to pass to the iPhone Shortcut"
}
Choose an action only when the user clearly asks for it.
For openApp, input is the app name.
For reminder, input is the reminder text.
For timer, input is the timer request, e.g. "10 minutes".
For note, input is the note text.
For webSearch, input is the search query.
For music, input is what the user wants to play.
Never claim that an action has already happened; the iPhone Shortcut performs it.`
        },
        { role: "user", content: message }
      ]
    });

    const raw = response.output_text.trim();
    let data;
    try {
      data = JSON.parse(raw);
    } catch {
      data = { reply: raw, action: "none", input: "" };
    }

    if (!shortcutNames[data.action]) data.action = "none";

    res.json({
      reply: String(data.reply || "Ready."),
      action: data.action,
      shortcut: shortcutNames[data.action] || null,
      input: String(data.input || "")
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "JARVIS backend error" });
  }
});

app.listen(port, () => console.log(`JARVIS V2 listening on port ${port}`));
