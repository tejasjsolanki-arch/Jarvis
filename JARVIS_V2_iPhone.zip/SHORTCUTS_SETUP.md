# JARVIS V2 — iPhone Shortcuts

Create these six shortcuts on your iPhone. Apple Shortcuts can chain actions and can be run by Siri or from other apps.

IMPORTANT: Shortcut names must exactly match these names because the web app launches them through the iOS Shortcuts URL scheme.

## 1. JARVIS Open App

Actions:
1. Ask for Input (Text) — prompt: "Which app?"
2. Choose from Menu — add your commonly used apps.
3. For each menu item, use Open App.

The web app passes the requested app name as Shortcut Input. For a simple version, replace Ask for Input with a fixed menu.

## 2. JARVIS Timer

Actions:
1. Get Shortcut Input.
2. If the input contains a duration, extract/choose the duration.
3. Set Timer.
4. Speak Text: "Timer started."

The exact duration parsing can be customized for the phrases you use.

## 3. JARVIS Reminder

Actions:
1. Get Shortcut Input.
2. Add New Reminder.
3. Use Shortcut Input as the reminder title.
4. Show Notification: "Reminder created."

## 4. JARVIS Note

Actions:
1. Get Shortcut Input.
2. Append Text to Note or Create Note.
3. Speak Text: "Note saved."

## 5. JARVIS Web Search

Actions:
1. Get Shortcut Input.
2. Search Web / Open URLs.
3. Use the input as the search query.

## 6. JARVIS Music

Actions:
1. Use the music app action available on your iPhone.
2. Play Music / Play Playlist / Resume Playback.

Apple notes that many apps expose their own App Shortcuts and those can be added into custom shortcuts.

## Siri

After creating the shortcuts, say:
"Hey Siri, JARVIS Timer"
or
"Hey Siri, JARVIS Open App"

Shortcuts can also be run from the Home Screen.

## Security

Only run shortcuts and JavaScript you trust. Apple provides privacy/security controls for shortcuts that interact with webpages.
